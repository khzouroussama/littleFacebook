package com.usthb.modeles;

import java.util.Date;
import java.util.LinkedList;

//Cette class sert a returner l'abonne sans ces champs critique

public class SafeAbonne extends Abonne {
    public SafeAbonne(String nom, String prenom, String username, String specialite, String fonction, String niveau, Date date_N) {
        super(nom, prenom, username, "******", specialite, fonction, niveau, date_N); //Pour cacher la mot pass
    }
    static SafeAbonne getSafeAbonne(Abonne a){
        SafeAbonne safeAbonne=new SafeAbonne(a.nom,a.prenom,a.username,a.specialite,a.fonction,a.niveau,a.Date_N);
        safeAbonne.publications=a.publications;
        return safeAbonne;
    }
}
