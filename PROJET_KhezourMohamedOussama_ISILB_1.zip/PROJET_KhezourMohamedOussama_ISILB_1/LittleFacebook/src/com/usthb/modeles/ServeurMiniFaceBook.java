package com.usthb.modeles;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

public class ServeurMiniFaceBook {
    private static HashMap<String,Abonne> baseAbonne=new HashMap<String,Abonne>();

    private static Abonne seConnecter(String username,String password){
        if(baseAbonne.containsKey(username)){
            Abonne abonne=baseAbonne.get(username);
            if (abonne.verfierMotPass(password)){
                abonne.setOnline(true);
                return baseAbonne.get(username);
            }
        }
        return null;
    }

    private static void publier(String username,Publication publication){
        if (baseAbonne.containsKey(username))
            baseAbonne.get(username).publications.addFirst(publication);
    }
    private static void inscrireAbonne(Abonne a){
        baseAbonne.put(a.getUsername(),a);
    }

    private static void supprimerAbonne(String username){
        baseAbonne.remove(username);
    }

    private static void rajouterCommentaire(int numPub,String username,String commenteur,StringBuilder contenu){
        if (baseAbonne.containsKey(username))
            for (Publication pub:baseAbonne.get(username).publications) {
                if(pub.getNum() == numPub)
                    pub.commentaires.add(new Commentaire(commenteur,contenu));
            }
    }

    private static void partager(Abonne a,Publication pub){
        a.publications.add(pub);
    }


    private static void reagir(int numPub,String username,String visiteur,Reaction reaction){
        if (baseAbonne.containsKey(username))
            for (Publication pub:baseAbonne.get(username).publications) {
                if(pub.getNum() == numPub)
                    pub.reactions.put(visiteur,reaction);
            }
    }

    private static void epingler(int numPub,String username){
        for (Publication pub :
             baseAbonne.get(username).publications) {
                if (numPub == pub.getNum())
                    pub.setEpinglee(true);
        }

    }

    private static SafeAbonne rechercher(String username){
        if (baseAbonne.containsKey(username))
            return SafeAbonne.getSafeAbonne(baseAbonne.get(username));
        return null;
    }

    private static void desepingler(int numPub,String username){
        for (Publication pub :
                baseAbonne.get(username).publications) {
            if (numPub == pub.getNum())
                pub.setEpinglee(false);
        }

    }
    private static void ajouterInvitation(String inviteur,String invite){
        if (baseAbonne.containsKey(inviteur))
            baseAbonne.get(invite).getListdinvitation().addFirst(new Invitation(inviteur,E_invitation.EN_INSTANCE));
    }

    private static void modifierEtatDeInvitation(String inviteur,String invite,E_invitation e_invitation){
        if (baseAbonne.containsKey(inviteur)){
            if (e_invitation.equals(E_invitation.ACCEPTEE)){
                for (Invitation invitation:
                     baseAbonne.get(invite).getListdinvitation()) {
                    if (invitation.username.equals(inviteur)){
                        invitation.setEtat(e_invitation);
                        baseAbonne.get(invite).getAmis().add(baseAbonne.get(inviteur));
                        baseAbonne.get(inviteur).getAmis().add(baseAbonne.get(invite));//car AMI_DE est une relation reflixive
                    }
                    else
                        invitation.setEtat(E_invitation.REFUSEE);
                }
            }
        }
    }

    private static void seDeconnecter(String username){
        baseAbonne.get(username).setOnline(false);
    }

    public static void main(String[] args) throws IOException {
        baseAbonne.put("oussama",new Abonne("Khezour","mohamed","oussama","123456","MI","isil","2",new Date()));
        ServerSocket serverSocket= null;
        ObjectOutputStream out = null;
        ObjectInputStream in=null;
        Abonne abonne;
        Socket socket=null;
        while (true){
            try {
                serverSocket = new ServerSocket(99);
                socket=serverSocket.accept();
                System.out.println("*Connexion etablie");
                in  =new ObjectInputStream(socket.getInputStream());
                out =new ObjectOutputStream(socket.getOutputStream());
                // les operations de serveur ..
                //On doit toujour commencer la disscution (serveur/client) par une commande [CommandesClientServeur]
                switch ((CommandesClientServeur)in.readObject()){
                    case SECONNECTER:
                        abonne=seConnecter((String)in.readObject(),(String)in.readObject());
                        out.writeObject(abonne);
                        if (abonne != null)
                            System.out.println("+["+abonne.username+"] est Connectee...");
                        break;
                    case INSCRIRE:
                        abonne=(Abonne)in.readObject();
                        if(baseAbonne.containsKey(abonne.username)){
                            out.writeBoolean(true);
                            out.flush();
                        }
                        else
                        {
                            out.writeBoolean(false);
                            out.flush();
                            inscrireAbonne(abonne);
                            System.out.println("+["+abonne.username+"] est inscrit ...");
                        }
                        break;
                    case AJOUTER_PUB:
                        String username=(String)in.readObject();
                        Publication pub=new Publication((String)in.readObject(),(VisibiltePub)in.readObject());
                        out.writeObject(pub);
                        out.flush();
                        publier(username,pub);
                        System.out.println("+["+username+"] a ajoutee une publication N:"+pub.getNum());
                        break;
                    case RAJOUTER_COMMENTAIRE:
                        int Num_publication=in.read();
                        String usr_c1=(String)in.readObject();
                        String usr_c2=(String)in.readObject();
                        out.write(1);
                        out.flush();

                        StringBuilder con=new StringBuilder((String)in.readObject());
                        rajouterCommentaire(Num_publication,usr_c1,usr_c2,con);
                        System.out.println("+["+usr_c2+"] a ajoutee un commentaire a pub N : ["+Num_publication+"]...");
                        break;
                    case REAGIR:
                        int Num_publication_r=in.read();
                        String usr1_r=(String)in.readObject();
                        String usr2_r=(String)in.readObject();
                        reagir(Num_publication_r,usr1_r,usr2_r,(Reaction)in.readObject());
                        out.write(1);
                        out.flush();
                        System.out.println("+["+usr2_r+"] a reagir a pub N : ["+Num_publication_r+"]...");
                        break;
                    case RECHERCHER:
                        String username_rech=(String)in.readObject();
                        out.writeObject(rechercher(username_rech));
                        out.flush();
                        break;
                    case ENVOYER_INVITATION:
                        String usr_inviteur=(String)in.readObject();
                        String usr_invite=(String)in.readObject();
                        out.write(1);
                        out.flush();
                        ajouterInvitation(usr_inviteur,usr_invite);
                        System.out.println("+["+usr_inviteur+"] a ajouter une invitation a : ["+usr_invite+"]...");
                        break;
                    case CHANGER_ETAT_INVITATION:
                        String usr_invite0=(String)in.readObject();
                        String usr_inviteur0=(String)in.readObject();
                        E_invitation eInvitation=(E_invitation)in.readObject();
                        out.write(1);
                        out.flush();
                        modifierEtatDeInvitation(usr_inviteur0,usr_invite0,eInvitation);
                        System.out.println("+["+usr_invite0+"] Changer l'etat de l'invitation de : ["+usr_inviteur0+"] a "+eInvitation+"...");
                        break;
                    case DECONNECTER:
                        String user_d=(String)in.readObject();
                        seDeconnecter(user_d);
                        System.out.println("+["+user_d+"] a ete deconnecter");
                        out.write(1);
                        out.flush();

                        break;

                }


            } catch (IOException e) {
                System.out.println(e+" -[problem de connexion]-");

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                in.close();
                out.close();
                serverSocket.close();
                socket.close();
            }

        }

    }

}
