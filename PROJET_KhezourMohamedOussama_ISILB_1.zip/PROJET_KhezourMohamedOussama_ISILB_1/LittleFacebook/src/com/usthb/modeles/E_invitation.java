package com.usthb.modeles;

public enum E_invitation {
    ACCEPTEE,REFUSEE,EN_INSTANCE
}
