package com.usthb.modeles;

import java.io.Serializable;

public class Commentaire implements Serializable {
    String username;
    StringBuilder Contenu;

    public Commentaire(String username, StringBuilder contenu) {
        this.username = username;
        Contenu = contenu;
    }

    public String getUsername() {
        return username;
    }

    public StringBuilder getContenu() {
        return Contenu;
    }
}
