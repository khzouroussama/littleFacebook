package com.usthb.modeles;

public class Notification {
    StringBuilder information;
    E_Notification etat;
}
