package com.usthb.modeles;

public enum CommandesClientServeur {
    //enumeration coresspondant  a commands de connexion entre le serveure est le client
    //tout les fonctionalite indique marche tres bien :)
    SECONNECTER,INSCRIRE,AJOUTER_PUB,RAJOUTER_COMMENTAIRE,REAGIR,RECHERCHER,ENVOYER_INVITATION,CHANGER_ETAT_INVITATION,DECONNECTER
}
