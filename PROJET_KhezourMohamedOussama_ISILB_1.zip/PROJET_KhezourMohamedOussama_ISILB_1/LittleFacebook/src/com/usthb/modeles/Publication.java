package com.usthb.modeles;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;

public class Publication implements Serializable{
    static int num=0;
    private int numPub;
    String contenu;
    VisibiltePub visibilite;
    boolean epinglee;


    /* si on utilise hashmap l'utilisateur ne peut ajouter qu'un seul commentaire donc je vais utilser une seul liste
    HashMap<String,StringBuilder> commentaires;
    */
    LinkedList<Commentaire> commentaires;
    HashMap<String,Reaction> reactions;

    public Publication(String contenu, VisibiltePub visibilite,boolean virtual) {
        if (! virtual)
            num++;
        commentaires= new LinkedList<Commentaire>();
        reactions=new HashMap<String, Reaction>();
        this.contenu = contenu;
        this.visibilite = visibilite;
        this.numPub=num;
    }

    public Publication(String contenu, VisibiltePub visibilite) {
        this(contenu,visibilite,false);
    }


    public int getNum() {
        return numPub;
    }

    public String getContenu() {
        return contenu;
    }

    public VisibiltePub getVisibilite() {
        return visibilite;
    }

    public boolean isEpinglee() {
        return epinglee;
    }

    public void setVisibilite(VisibiltePub visibilite) {
        this.visibilite = visibilite;
    }

    public void setEpinglee(boolean epinglee) {
        this.epinglee = epinglee;
    }

    public LinkedList<Commentaire> getCommentaires() {
        return commentaires;
    }

    public HashMap<String, Reaction> getReactions() {
        return reactions;
    }
}
