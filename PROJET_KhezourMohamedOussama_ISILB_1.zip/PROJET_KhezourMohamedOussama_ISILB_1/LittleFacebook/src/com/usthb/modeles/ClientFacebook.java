package com.usthb.modeles;

import com.alee.extended.date.WebDateField;
import com.alee.extended.layout.FormLayout;
import com.alee.laf.WebLookAndFeel;
import com.alee.laf.button.WebButton;
import com.alee.laf.label.WebLabel;
import com.alee.laf.menu.MenuBarStyle;
import com.alee.laf.menu.WebMenu;
import com.alee.laf.menu.WebMenuBar;
import com.alee.laf.menu.WebMenuItem;
import com.sun.awt.AWTUtilities;
import com.usthb.modeles.MesComposontGraphique.PublicationGraphique;
import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.BorderUIResource;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Date;
import java.util.Scanner;

//pour changer le look and feel

public class ClientFacebook{
     Abonne abonne=new Abonne();
     private static Scanner sc=new Scanner(System.in);
     public static Font fontdeFENs;

    JFrame murframe,Loginframe;

     public ClientFacebook() {
        //initialiser les fonts
         fontdeFENs=new Font("Segoe UI",Font.BOLD,14);
         UIManager.put("Button.font",fontdeFENs.deriveFont(Font.BOLD,14));
         UIManager.put("TitledBorder.font",fontdeFENs);
         UIManager.put("TabbedPane.font",fontdeFENs);


         initLeLogIn();
     }

     //initialiser La fenetre coresspendant a inscrire ou conneceter
     private void initLeLogIn(){
         Loginframe=new JFrame("Login");
         Loginframe.setIconImage(new ImageIcon("Images/global.png").getImage());
         //supprimer le titre de fenetre----
         Loginframe.setUndecorated(true);
         AWTUtilities.setWindowOpaque(Loginframe,false);

         Loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         Toolkit toolkit = Loginframe.getToolkit();
         Dimension size = toolkit.getScreenSize();
         Loginframe.setMinimumSize(new Dimension(500, 700));

         //mettre la fenetre au centre de l'ecran

         Loginframe.setLocation(size.width / 2 - Loginframe.getWidth() / 2,
                               size.height / 2 - Loginframe.getHeight() / 2);

         //panel Initiale-----declaration
         JPanel panel=new JPanel(new BorderLayout());
         TitledBorder titledBorder=BorderFactory.createTitledBorder(" LittelFaceBook ");
         titledBorder.setTitleJustification(TitledBorder.CENTER);
         titledBorder.setTitleColor(new Color(82,127,255));
         Font fonte = new Font("Ubuntu",Font.BOLD,24);
         titledBorder.setTitleFont(fonte);
         panel.setBorder(titledBorder);
         //panel initiale ---- fin declaration;

            JPanel logFormpan=new JPanel(new FlowLayout(FlowLayout.CENTER,10,5));

            //inscrire Form --Declarations
         JPanel Pereinscrire=new JPanel(new BorderLayout(10,10));
         JPanel inscrirFormpan=new JPanel(new FormLayout(5,5));
         //temp--
         inscrirFormpan.setBorder(BorderFactory.createTitledBorder("Inscrire Maintenant "));
         logFormpan.setBorder(BorderFactory.createTitledBorder("SingIn "));
         ///////////////////////////Remplissage de LoginForm
         /*---- lescomposant declaration/init------*/
         //
         JTextField userLOGtf=new JTextField(15);
         JPasswordField passLOGf=new JPasswordField(15);
         //login button---declaration
         JButton loginbtn=new JButton(" Login ");
         loginbtn.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
         loginbtn.setForeground(Color.WHITE);
         //---- l'action pour login
         loginbtn.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent actionEvent) {
                 Socket socket=null;
                 ObjectOutputStream out=null;
                 ObjectInputStream in=null;
                 if ( ! (userLOGtf.getText().isEmpty() || String.valueOf(passLOGf.getPassword()).isEmpty()) )
                 try {
                     socket=new Socket("127.0.0.1",99);
                     out=new ObjectOutputStream(socket.getOutputStream());
                     in=new ObjectInputStream(socket.getInputStream());
                     out.writeObject(CommandesClientServeur.SECONNECTER);
                     out.flush();
                     out.writeObject(userLOGtf.getText());
                     out.flush();
                     out.writeObject(String.valueOf(passLOGf.getPassword()));
                     out.flush();

                     abonne=(Abonne)in.readObject();
                     if (abonne == null)
                         JOptionPane.showMessageDialog(Loginframe,"la mot pass ou username est incorrect ","Erreur de Connexion",JOptionPane.WARNING_MESSAGE);
                     else
                     {
                         Loginframe.setVisible(false);
                         //faire l'appel a la fentre de mure
                         initLeMure();
                         murframe.setVisible(true);
                     }

                 } catch (IOException e) {
                     JOptionPane.showMessageDialog(Loginframe,"  Desole,erreur de connexion :"+e.getMessage(),"Erreur de Connexion",JOptionPane.ERROR_MESSAGE);;
                 } catch (ClassNotFoundException e) {
                     e.printStackTrace();
                 } finally {
                     try {
                         socket.close();
                         in.close();
                         out.close();
                     } catch (IOException e) {
                         e.printStackTrace();
                     }

                 }

             }
         });
                // loginbtn.setFont(fonte);dont!
         //REmplisage --
         logFormpan.add(new JLabel("   Username"));
         logFormpan.add(userLOGtf);
         logFormpan.add(new JLabel("   Password"));
         logFormpan.add(passLOGf);
         logFormpan.add(loginbtn);
         ///////////////////////////Remplissage de Inscrire forme
         /*---- lescomposant declaration/init------*/
         JTextField nomTF,preTF,userTF,specTF,foncTF,nivTF;
         JPasswordField passPF,passPF2;
         JLabel etatIN;
         nomTF=new JTextField(10);
         preTF=new JTextField(10);
         userTF=new JTextField(10);
         passPF=new JPasswordField(10);
         passPF2=new JPasswordField(10);
         specTF=new JTextField(10);
         foncTF=new JTextField(10);
         nivTF=new JTextField(10);
         etatIN=new JLabel("l etat de l'inscription ");
         etatIN.setVisible(false);
         WebDateField DNField = new WebDateField(new Date());
         inscrirFormpan.add(new JLabel("    Nom "));
         inscrirFormpan.add(nomTF);
         inscrirFormpan.add(new JLabel("    Prenome "));
         inscrirFormpan.add(preTF);
         inscrirFormpan.add(new JLabel("    Date de Naissance  "));
         inscrirFormpan.add(DNField);
         inscrirFormpan.add(new JLabel("    UserName"));
         inscrirFormpan.add(userTF);
         inscrirFormpan.add(new JLabel("    Password "));
         inscrirFormpan.add(passPF);
         inscrirFormpan.add(new JLabel("    Password again"));
         inscrirFormpan.add(passPF2);
         inscrirFormpan.add(new JLabel("    Specialite "));
         inscrirFormpan.add(specTF);
         inscrirFormpan.add(new JLabel("    Fonction "));
         inscrirFormpan.add(foncTF);
         inscrirFormpan.add(new JLabel("    Niveau  "));
         inscrirFormpan.add(nivTF);
         inscrirFormpan.add(etatIN);

         //----
         Pereinscrire.add(inscrirFormpan,BorderLayout.SOUTH);//Image de Reception ICI******
         Pereinscrire.add(new JLabel(new ImageIcon("Images/LOGOLFB.png")),BorderLayout.CENTER);

         //Ajouter les sous panel a panel Initiale
         panel.add(logFormpan,BorderLayout.NORTH);
         panel.add(Pereinscrire,BorderLayout.CENTER);
         JButton INscrirBtn=new JButton("Inscrire Maintenant !!");
         INscrirBtn.setForeground(Color.WHITE);
         INscrirBtn.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
         INscrirBtn.setToolTipText("<html><body>In case you thought that tooltips had to be<p>boring, one line descriptions, the <font color=blue size=+2>Swing!</font> team<p>is happy to shatter your illusions.<p>In Swing, you can use HTML to <ul><li>Have Lists<li><b>Bold</b> text<li><em>emphasized</em>text<li>text with <font color=red>Color</font><li>text in different <font size=+3>sizes</font><li>and <font face=AvantGarde>Fonts</font></ul>Oh, and they can be multi-line, too.</body></html>");
         //---Action de l'inscription
         INscrirBtn.addActionListener(new ActionListener() {
             private void EtatAlert(String alertText,Color color){
                 etatIN.setForeground(color);
                 etatIN.setVisible(true);
                 etatIN.setText(alertText);
             }

             @Override
             public void actionPerformed(ActionEvent actionEvent) {
                 //les Controle de text fields
                 if (nomTF.getText().isEmpty() || preTF.getText().isEmpty() || userTF.getText().isEmpty() || String.valueOf(passPF.getPassword()).isEmpty()
                         || String.valueOf(passPF2.getPassword()).isEmpty() || specTF.getText().isEmpty() || foncTF.getText().isEmpty() || nivTF.getText().isEmpty())
                     EtatAlert("+Champs non remplit ",Color.red);

                 else if (! String.valueOf(passPF.getPassword()).equals(String.valueOf(passPF2.getPassword())))
                         EtatAlert("+motpass non identique",Color.red);
                     else{
                         Socket socket=null;
                         ObjectOutputStream out=null;
                         ObjectInputStream in=null;
                         try {
                             socket=new Socket("127.0.0.1",99);
                             out=new ObjectOutputStream(socket.getOutputStream());
                             in=new ObjectInputStream(socket.getInputStream());
                             //TODO  user name must be unique (tomorrow)
                             out.writeObject(CommandesClientServeur.INSCRIRE);
                             out.flush();
                             out.writeObject(new Abonne(nomTF.getText(),preTF.getText(),userTF.getText(),String.valueOf(passPF.getPassword()),specTF.getText(),foncTF.getText(),nivTF.getText(),DNField.getDate()));
                             out.flush();
                             if(in.readBoolean())
                                 EtatAlert("+username deja exist",Color.red);
                             else {
                                 EtatAlert("+Inscription Termine!",Color.green);
                                 JOptionPane.showMessageDialog(Loginframe,"Vous etes inscrit maintenant vous pouvez vous connecter","inscription terminer",JOptionPane.INFORMATION_MESSAGE);
                             }

                         } catch (IOException e) {
                             JOptionPane.showMessageDialog(Loginframe,"  Desole,erreur de connexion :"+e.getMessage(),"Erreur de Connexion",JOptionPane.ERROR_MESSAGE);;
                         } finally {
                             try {
                                 in.close();
                                 socket.close();
                                 out.close();
                             } catch (IOException e) {
                                 e.printStackTrace();
                             }

                         }

                     }
             }
         });
         panel.add(INscrirBtn,BorderLayout.SOUTH);


         Loginframe.setContentPane(panel);

         Loginframe.pack();

     }

     private void initLeMure(){
             murframe=new JFrame("Bonjour "+abonne.prenom+" "+abonne.nom);
             murframe.setUndecorated(true);
             murframe.setIconImage(new ImageIcon("Images/global.png").getImage());
            AWTUtilities.setWindowOpaque(murframe,false);
      //     murframe.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
             murframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

             Toolkit toolkit = murframe.getToolkit();
             Dimension size = toolkit.getScreenSize();
             murframe.setPreferredSize(new Dimension(800,600));

             //mettre la fenetre au centre de l'ecran


             murframe.setLocation(size.width / 2 -murframe.getWidth()/2,
                     size.height / 2 -murframe.getHeight()/2);

             JPanel principalPAN=new JPanel(new BorderLayout());
             JTabbedPane Tabedpane=new JTabbedPane(JTabbedPane.RIGHT);
             JPanel panel=new JPanel(new BorderLayout());
             JPanel panel1=new JPanel();

             //TODO list des abonne connecte////////////////////////////////////////
             JPanel conectedPan=new JPanel(new GridLayout(10,1,10,10));
             conectedPan.setBorder(BorderFactory.createTitledBorder("Mes Amis"));
             conectedPan.setBackground(new Color(230,230,230));
             for (Abonne aBNe:abonne.getAmis()){
                 WebLabel webLabel=new WebLabel(aBNe.username,new ImageIcon("Images/user2.png"));
                 webLabel.setBorder(BorderFactory.createTitledBorder(""));
                 conectedPan.add(webLabel);
             }

            //TODO LIST des PUBLiCATION (mu)/////////////////////////
             PublicationGraphique[] pubpan=new PublicationGraphique[8];
             JPanel list=new JPanel();
             list.setLayout(new BoxLayout(list,BoxLayout.Y_AXIS));
             panel.add(new JScrollPane(list),BorderLayout.CENTER);
             //
             //pane a ajouter une publication
             JPanel ajoutPub=new JPanel(new BorderLayout(5,5));
                JPanel publierBar=new JPanel(new FlowLayout(FlowLayout.RIGHT));
                    String[] vis=new String[]{"prive", "public", "ami", "listeAmis", "groupe"};
                    JComboBox VISIBILITEbox=new JComboBox(vis);
                    JButton postbtn=new JButton("Post !");
                    postbtn.setForeground(Color.WHITE);
                    postbtn.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
                    publierBar.add(VISIBILITEbox);
                    publierBar.add(postbtn);
                    JTextArea pubtext=new JTextArea("Exprimez  vous "+abonne.nom+" !",3,4);
                    ////////////////////////////////////////
                    pubtext.addFocusListener(new FocusListener() {
                        @Override
                        public void focusGained(FocusEvent e) {

                        }

                        @Override
                        public void focusLost(FocusEvent e) {
                            if(pubtext.getText().equals(""))
                                pubtext.setText("Exprimez  vous "+abonne.nom+" !");
                        }
                    });
                    pubtext.addMouseListener(new MouseListener() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
                            if(pubtext.getText().equals("Exprimez  vous "+abonne.nom+" !"))
                                pubtext.setText("");
                        }

                        @Override
                        public void mousePressed(MouseEvent e) {

                        }

                        @Override
                        public void mouseReleased(MouseEvent e) {

                        }

                        @Override
                        public void mouseEntered(MouseEvent e) {
                        }

                        @Override
                        public void mouseExited(MouseEvent e) {

                        }
                    });
                    pubtext.setFont(fontdeFENs.deriveFont(Font.ITALIC));
                    JLabel nopubs=new JLabel("pas de publicaions pour l'instant");
                    nopubs.setForeground(Color.gray);
                    nopubs.setPreferredSize(new Dimension(50,300));

                    postbtn.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent event) {

                            if (pubtext.getText().isEmpty())
                                JOptionPane.showMessageDialog(murframe,"pas de contenu dans la publication","Ajouter un text",JOptionPane.QUESTION_MESSAGE);
                            else
                            {
                                Socket socket=null;
                                ObjectOutputStream out=null;
                                ObjectInputStream in=null;
                                try {
                                    socket=new Socket("127.0.0.1",99);
                                    out=new ObjectOutputStream(socket.getOutputStream());
                                    in=new ObjectInputStream(socket.getInputStream());
                                    out.writeObject(CommandesClientServeur.AJOUTER_PUB);
                                    out.flush();
                                    out.writeObject(abonne.username);
                                    out.flush();
                                    String contenu_de_pub=(pubtext.getText());
                                    VisibiltePub visibilite_de_pub=VisibiltePub.valueOf(((String)VISIBILITEbox.getSelectedItem()).toUpperCase());
                                        out.writeObject(contenu_de_pub);
                                        out.flush();
                                        out.writeObject(visibilite_de_pub);
                                        out.flush();

                                        list.add(new PublicationGraphique((Publication)in.readObject(),abonne.username,abonne.username),1);
                                        pubtext.setText("");
                                        nopubs.setVisible(false);
                                } catch (IOException e) {
                                    JOptionPane.showMessageDialog(murframe,"  Desole,erreur de connexion :"+e.getMessage(),"Erreur de Connexion",JOptionPane.ERROR_MESSAGE);
                                } catch (ClassNotFoundException e) {
                                    e.printStackTrace();
                                } finally {
                                    try {
                                        socket.close();
                                        out.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    });

         ////
                    publierBar.setBackground(new Color(250,250,240));
                    publierBar.setBorder(BorderFactory.createLineBorder(Color.lightGray,1,true));
                    ajoutPub.setBackground(new Color(240,240,240));
                    ajoutPub.add(pubtext,BorderLayout.CENTER);
                    ajoutPub.add(publierBar,BorderLayout.SOUTH);
                    ajoutPub.add(new JLabel(new ImageIcon(new ImageIcon("Images/user.png").getImage().getScaledInstance(50,50,Image.SCALE_SMOOTH))),BorderLayout.WEST);
                    ajoutPub.setBorder(BorderFactory.createTitledBorder("Ajouter une Publication"));
                ///////////////////////////////////////////////
             list.add(ajoutPub);
             if (! abonne.publications.isEmpty())
                for (Publication publication:abonne.publications){
                     PublicationGraphique pubGRPH=new PublicationGraphique(publication,abonne.username,abonne.username);
                     list.add(pubGRPH);
                     list.add(new JLabel("    "));
                     list.revalidate();
                }
             else
                 list.add(nopubs);

             //TODO//////////////////////
             Tabedpane.addTab("    Le  Mure ",new ImageIcon("Images/home.png"),panel);
             Tabedpane.addTab("Mon Profile",new ImageIcon("Images/user4.png"),panel1);

             Tabedpane.setBackground(new Color(230,230,230));
             Tabedpane.addChangeListener(new ChangeListener() {
                 @Override
                 public void stateChanged(ChangeEvent changeEvent) {
                     Tabedpane.setForegroundAt(0,Color.lightGray);
                     Tabedpane.setForegroundAt(1,Color.lightGray);
                     Tabedpane.setForegroundAt(Tabedpane.getSelectedIndex(),Color.BLACK);
                 }
             });
             Tabedpane.setOpaque(true); //content panes must be opaque
             principalPAN.add(Tabedpane,BorderLayout.CENTER);
             //
             //JToolBar toolBar=new JToolBar("llll");//annuler

             //menu des invitation
         //TODO les menu  des invitation/notification
             JMenuBar menuBar_invitation=new JMenuBar();
             //menuBar_invitation.setPreferredSize(new Dimension(100,50));
             menuBar_invitation.setBorder(BorderFactory.createLineBorder(new Color(220,220,220),1,true));

         //menuBar_invitation.;
             JMenu invitation=new JMenu("Invitation");
             invitation.setForeground(Color.blue);
             invitation.setFont(fontdeFENs.deriveFont(Font.PLAIN,12));
             //invitation.setPreferredSize(new Dimension(60,50));
             for (Invitation inv:abonne.getListdinvitation()) {
                 JMenuItem inv_item = new JMenuItem();
                 inv_item.setBackground(new Color(220,220,220));
                 inv_item.setPreferredSize(new Dimension(220, 40));
                 inv_item.setLayout(new FlowLayout(FlowLayout.CENTER, 1, 1));
                 inv_item.add(new JLabel(inv.username+ "   ", new ImageIcon("Imagess/user2.png"), SwingConstants.LEFT));


                 if (inv.etat.equals(E_invitation.EN_INSTANCE)){
                     JButton button2 = new JButton("Confirme");
                     JButton button3 = new JButton("refuse");
                     inv_item.add(button2);
                     inv_item.add(button3);
                     button2.addActionListener(new ActionListener() {
                         @Override
                         public void actionPerformed(ActionEvent event) {
                             Socket socket=null;
                             ObjectOutputStream out=null;
                             ObjectInputStream in=null;
                             try {
                                 socket=new Socket("127.0.0.1",99);
                                 out=new ObjectOutputStream(socket.getOutputStream());
                                 in=new ObjectInputStream(socket.getInputStream());
                                 out.writeObject(CommandesClientServeur.CHANGER_ETAT_INVITATION);
                                 out.flush();
                                 out.writeObject(abonne.username);
                                 out.flush();
                                 out.writeObject(inv.username);
                                 out.writeObject(E_invitation.ACCEPTEE);
                                 out.flush();
                                 in.read();
                                 inv_item.remove(button2);
                                 inv_item.remove(button3);
                                 inv_item.add(new JLabel("Invitation Accepter"));

                             } catch (IOException e) {
                                 JOptionPane.showMessageDialog(murframe, "  Desole,erreur de connexion :" + e.getMessage(), "Erreur de Connexion", JOptionPane.ERROR_MESSAGE);
                             } finally {
                                 try {
                                     socket.close();
                                     out.close();
                                 } catch (IOException e) {
                                     e.printStackTrace();
                                 }
                             }
                         }
                     });
                     button2.setFont(fontdeFENs.deriveFont(Font.PLAIN, 10));
                     button2.setMargin(new Insets(0, 2, 0, 2));
                     button3.addActionListener(new ActionListener() {
                         @Override
                         public void actionPerformed(ActionEvent event) {
                             Socket socket=null;
                             ObjectOutputStream out=null;
                             ObjectInputStream in=null;
                             try {
                                 socket=new Socket("127.0.0.1",99);
                                 out=new ObjectOutputStream(socket.getOutputStream());
                                 in=new ObjectInputStream(socket.getInputStream());
                                 out.writeObject(CommandesClientServeur.CHANGER_ETAT_INVITATION);
                                 out.flush();
                                 out.writeObject(abonne.username);
                                 out.flush();
                                 out.writeObject(inv.username);
                                 out.writeObject(E_invitation.REFUSEE);
                                 out.flush();
                                 in.read();
                                 inv_item.remove(button2);
                                 inv_item.remove(button3);
                                 inv_item.add(new JLabel("Invitation refuser"));

                             } catch (IOException e) {
                                 JOptionPane.showMessageDialog(murframe, "  Desole,erreur de connexion :" + e.getMessage(), "Erreur de Connexion", JOptionPane.ERROR_MESSAGE);
                             } finally {
                                 try {
                                     socket.close();
                                     out.close();
                                 } catch (IOException e) {
                                     e.printStackTrace();
                                 }
                             }
                         }
                     });
                     button3.setMargin(new Insets(0, 2, 0, 2));
                     button3.setFont(fontdeFENs.deriveFont(Font.PLAIN, 10));

                 }else inv_item.add(new JLabel("Invitation "+inv.etat));




                 invitation.add(inv_item);
             }
                //deconnexion
             WebButton deconexion=new WebButton("Deconnecter");
             deconexion.addActionListener(new ActionListener() {
                 @Override
                 public void actionPerformed(ActionEvent event) {
                     Socket socket=null;
                     ObjectOutputStream out=null;
                     ObjectInputStream in=null;
                     try {
                         socket=new Socket("127.0.0.1",99);
                         out=new ObjectOutputStream(socket.getOutputStream());
                         in=new ObjectInputStream(socket.getInputStream());
                         out.writeObject(CommandesClientServeur.DECONNECTER);
                         out.flush();
                         out.writeObject(abonne.getUsername());
                         out.flush();
                         in.read();
                         murframe.setVisible(false);
                         Loginframe.setVisible(true);

                     } catch (IOException e) {
                         JOptionPane.showMessageDialog(murframe, "  Desole,erreur de connexion :" + e.getMessage(), "Erreur de Connexion", JOptionPane.ERROR_MESSAGE);
                     } finally {
                         try {
                             socket.close();
                             out.close();
                         } catch (IOException e) {
                             e.printStackTrace();
                         }
                     }
                 }
             });
             menuBar_invitation.add(deconexion);
             menuBar_invitation.add(invitation);
             menuBar_invitation.add(new JLabel("      "+abonne.getUsername()+"       ", new ImageIcon("Images/user4.png"),SwingConstants.LEFT));

             JButton bunRecherch=new JButton(new ImageIcon(new ImageIcon("Images/recherch.png").getImage().getScaledInstance(20,20,Image.SCALE_SMOOTH)));
             JTextField RecherchFild= new JTextField("rechercher a une abonne ici !!");
             menuBar_invitation.add(new JLabel("         "));
             menuBar_invitation.add(bunRecherch);
             menuBar_invitation.add(RecherchFild);
             //TODO event de REchercher
             bunRecherch.addActionListener(new ActionListener() {
                 @Override
                 public void actionPerformed(ActionEvent event) {
                     if (RecherchFild.getText().equals(abonne.getUsername()))
                         JOptionPane.showMessageDialog(murframe,"HADA NTA !!!!!!","???!!!!",JOptionPane.WARNING_MESSAGE);
                     if (! RecherchFild.getText().isEmpty() && !RecherchFild.getText().equals("rechercher a une abonne ici !!") && !RecherchFild.getText().equals(abonne.getUsername())){
                     Socket socket=null;
                     ObjectOutputStream out=null;
                     ObjectInputStream in=null;
                     try {
                         socket=new Socket("127.0.0.1",99);
                         out=new ObjectOutputStream(socket.getOutputStream());
                         in=new ObjectInputStream(socket.getInputStream());
                         out.writeObject(CommandesClientServeur.RECHERCHER);
                         out.flush();
                         out.writeObject(RecherchFild.getText());
                         out.flush();
                         SafeAbonne sAbonneVisite;
                         if ((sAbonneVisite=(SafeAbonne)in.readObject()) == null)
                             JOptionPane.showMessageDialog(murframe,"n'exist pas un abonne avec ce user name ", "Abonne not found !", JOptionPane.ERROR_MESSAGE);
                         else {
                             ///////////////*/*/*\//*///////////*/*/
                             /*info et ajouter invitation pane*/
                             JPanel infAjout=new JPanel(new BorderLayout(5,5));
                             infAjout.add(new JLabel(new ImageIcon("Images/user.png")),BorderLayout.CENTER);

                             JPanel ajouJPanel=new JPanel(new FlowLayout(FlowLayout.CENTER));
                             JButton ajoutfriendBTN;
                             if(abonne.amiDe(sAbonneVisite.getUsername()))
                                 ajoutfriendBTN=new JButton("Amie",new ImageIcon(new ImageIcon("Images/users.png").getImage().getScaledInstance(30,30,Image.SCALE_DEFAULT)));
                             else
                                if (abonne.aInvitationENDe(sAbonneVisite.getUsername()))
                                    ajoutfriendBTN = new JButton("invitation En instant ...", new ImageIcon("Images/adduser.png"));
                                else
                                    ajoutfriendBTN = new JButton("Inviter", new ImageIcon("Images/adduser.png"));


                             JButton fermeAbonneBTN=new JButton("Fermer",new ImageIcon("Images/exit.png"));

                             //les events!!!
                             fermeAbonneBTN.addActionListener(new ActionListener() {
                                 @Override
                                 public void actionPerformed(ActionEvent e) {
                                     int tmp=Tabedpane.getSelectedIndex();
                                     Tabedpane.setSelectedIndex(0);
                                     Tabedpane.remove(tmp);
                                 }
                             });

                             ajoutfriendBTN.addActionListener(new ActionListener() {
                                 @Override
                                 public void actionPerformed(ActionEvent event1) {
                                     if (! abonne.amiDe(sAbonneVisite.getUsername()) && !abonne.aInvitationENDe(sAbonneVisite.getUsername())){

                                     Socket socket=null;
                                     ObjectOutputStream out=null;
                                     ObjectInputStream in=null;
                                     try {
                                         socket=new Socket("127.0.0.1",99);
                                         out=new ObjectOutputStream(socket.getOutputStream());
                                         in=new ObjectInputStream(socket.getInputStream());
                                         out.writeObject(CommandesClientServeur.ENVOYER_INVITATION);
                                         out.flush();
                                         out.writeObject(abonne.getUsername());
                                         out.flush();
                                         out.writeObject(sAbonneVisite.getUsername());
                                         out.flush();
                                         in.read();
                                         ajoutfriendBTN.setText("Invitation En instant ...");

                                     } catch (IOException e) {
                                         JOptionPane.showMessageDialog(murframe, "  Desole,erreur de connexion :" + e.getMessage(), "Erreur de Connexion", JOptionPane.ERROR_MESSAGE);
                                     } finally {
                                         try {
                                             socket.close();
                                             out.close();
                                         } catch (IOException e) {
                                             e.printStackTrace();
                                         }
                                     }
                                 }else JOptionPane.showMessageDialog(murframe,"Deja Ami...","Deja Ami...",JOptionPane.QUESTION_MESSAGE);
                                 }
                             });


                             ajouJPanel.add(ajoutfriendBTN);
                             ajouJPanel.add(fermeAbonneBTN);
                             TitledBorder border=BorderFactory.createTitledBorder(sAbonneVisite.username);
                             border.setTitleJustification(TitledBorder.CENTER);
                             border.setTitleFont(fontdeFENs.deriveFont(Font.BOLD,20));
                             infAjout.add(ajouJPanel,BorderLayout.SOUTH);
                             infAjout.setBorder(border);

                             //////
                             JPanel AbonneMure=new JPanel(new BorderLayout());
                             JPanel list2=new JPanel();
                             list2.setLayout(new BoxLayout(list2,BoxLayout.Y_AXIS));
                             AbonneMure.add(new JScrollPane(list2),BorderLayout.CENTER);
                             list2.add(infAjout);
                             if (! sAbonneVisite.publications.isEmpty())
                                 for (Publication publication:sAbonneVisite.publications){
                                     PublicationGraphique pubGRPH=new PublicationGraphique(publication,sAbonneVisite.username,abonne.username);
                                     list2.add(pubGRPH);
                                     list2.add(new JLabel("    "));
                                     list2.revalidate();
                                 }
                             else
                                 list2.add(nopubs);
                            Tabedpane.addTab(sAbonneVisite.username,new ImageIcon("Images/user.png"),AbonneMure);
                            Tabedpane.setSelectedIndex(Tabedpane.getTabCount()-1);
                         }

                     } catch (IOException e) {
                         JOptionPane.showMessageDialog(murframe, "  Desole,erreur de connexion :" + e.getMessage(), "Erreur de Connexion", JOptionPane.ERROR_MESSAGE);
                     } catch (ClassNotFoundException e) {
                         e.printStackTrace();
                     } finally {
                         try {
                             socket.close();
                             out.close();
                         } catch (IOException e) {
                             e.printStackTrace();
                         }
                     }
                 }
                 }
             });

             menuBar_invitation.add(new JLabel("     "));
             menuBar_invitation.add(new JLabel(new ImageIcon("Images/global.png"),SwingConstants.LEFT));

         // toolBar
            // toolBar.setPreferredSize(new Dimension(toolBar.getWidth(),50));
            // toolBar.add(new JButton("Notification",new ImageIcon(new ImageIcon("Images/music.png").getImage().getScaledInstance(25,25,Image.SCALE_SMOOTH))));
             //toolBar.addSeparator();
             /*toolBar.addSeparator(new Dimension(70,0));

             toolBar.add(new JButton(new ImageIcon(new ImageIcon("Images/recherch.png").getImage().getScaledInstance(25,25,Image.SCALE_SMOOTH))));
             toolBar.add(new JTextField("recherche ici ...",10));
             toolBar.addSeparator(new Dimension(20,0));

         toolBar.add(new JLabel(new ImageIcon(new ImageIcon("Images/global.png").getImage().getScaledInstance(25,25,Image.SCALE_SMOOTH))));
         toolBar.addSeparator();

         toolBar.setFloatable(false);

         //pouur la ombre
             toolBar.putClientProperty("MenuBar.shadow", Boolean.TRUE);*/
            //principalPAN.add(toolBar);
            // principalPAN.add(toolBar,BorderLayout.NORTH);
             principalPAN.add(conectedPan,BorderLayout.WEST);
            murframe.setJMenuBar(menuBar_invitation);

             murframe.setContentPane(principalPAN);


         //Display the window.
            murframe.pack();
     }

     public static void main(String[] args) throws IOException {
         //Socket socket=new Socket("127.0.0.1",99);
         try {
               WebLookAndFeel.install();
               BeautyEyeLNFHelper.frameBorderStyle=BeautyEyeLNFHelper.FrameBorderStyle.translucencyAppleLike;

               org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();


               UIManager.put("RootPane.setupButtonVisible",false);//suppremer icon setup



             EventQueue.invokeLater(() -> {
                 ClientFacebook facebook = new ClientFacebook();
                 facebook.Loginframe.setVisible(true);

             });


         } catch (Exception e) {
             e.printStackTrace();
         }
        // socket.close();

     }
}
