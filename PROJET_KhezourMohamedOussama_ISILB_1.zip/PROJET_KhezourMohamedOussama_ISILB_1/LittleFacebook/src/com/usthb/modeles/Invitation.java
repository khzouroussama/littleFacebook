package com.usthb.modeles;

import java.io.Serializable;

public class Invitation implements Serializable {

    public Invitation(String username, E_invitation etat) {
        this.username = username;
        this.etat = etat;
    }

    String username,message;
    E_invitation etat;

    public void setEtat(E_invitation etat) {
        this.etat = etat;
    }
}
