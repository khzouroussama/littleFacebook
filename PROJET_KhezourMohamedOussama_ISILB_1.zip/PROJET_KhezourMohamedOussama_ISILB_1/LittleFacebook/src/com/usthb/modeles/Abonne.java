package com.usthb.modeles;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;

public class Abonne implements Serializable {
    static int num=0;
    public String nom,prenom,username,specialite,fonction,niveau;
    private String motpasse;
    private LinkedList<Abonne> amis;
    public LinkedList<Publication> publications;
    private LinkedList<Invitation> listdinvitation;
    boolean online;
    public Date Date_N=new Date();
    int numAbonne;


    public Abonne(String nom, String prenom, String username, String motpasse, String specialite, String fonction, String niveau, Date date_N) {
        num++;
        this.nom = nom;
        this.prenom = prenom;
        this.username = username;
        this.motpasse = motpasse;
        this.specialite = specialite;
        this.fonction = fonction;
        this.niveau = niveau;
        this.numAbonne=num;
        Date_N = date_N;
        amis = new LinkedList<Abonne>();
        publications = new LinkedList<Publication>();
        listdinvitation=new LinkedList<Invitation>();
    }

    public Abonne() {

    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public static int getNum() {
        return num;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getUsername() {
        return username;
    }

    boolean verfierMotPass(String autremotpass){
        return motpasse.equals(autremotpass);
    }

    public LinkedList<Invitation> getListdinvitation() {
        return listdinvitation;
    }

    public LinkedList<Abonne> getAmis() {
        return amis;
    }

    public boolean amiDe(String username){
        for (Abonne abonne:
             amis) {
            if (username.equals(abonne.getUsername()))
                return true;
        }
        return false;
    }
    public boolean aInvitationENDe(String user){
        for (Invitation inv :
                listdinvitation) {
            if (user.equals(inv.username) && inv.etat.equals(E_invitation.EN_INSTANCE))
                return true;
        }
        return false;
    }
}
