package com.usthb.modeles;

public enum VisibiltePub {
    PRIVE, PUBLIC, AMI, LISTEAMIS, GROUPE
}
