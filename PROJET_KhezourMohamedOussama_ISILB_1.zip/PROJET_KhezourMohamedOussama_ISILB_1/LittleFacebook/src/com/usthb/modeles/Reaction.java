package com.usthb.modeles;

public enum Reaction {
    JAIME,JADORE,GAI,TRISTE,ENCOLERE
}
