package com.usthb.modeles.MesComposontGraphique;

import com.usthb.modeles.CommandesClientServeur;
import com.usthb.modeles.Reaction;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/* LE class concerner a afficher le bar de reaction avec les evenements nessissaire */
public class RectionBar extends JPanel {
    public JToggleButton[] reactions=new JToggleButton[5];

    public RectionBar(int NumPub,String username,String visiteur) {
        super();
        setBorder(BorderFactory.createTitledBorder(""));
        reactions[0]=new JToggleButton("Jaime",new ImageIcon(new ImageIcon("Images/reactions/JAIME.png").getImage().getScaledInstance(25,25, Image.SCALE_SMOOTH)));
        reactions[1]=new JToggleButton("Jadore",new ImageIcon(new ImageIcon("Images/reactions/JADORE.png").getImage().getScaledInstance(25,25, Image.SCALE_SMOOTH)));
        reactions[2]=new JToggleButton("GAI",new ImageIcon(new ImageIcon("Images/reactions/GAI.png").getImage().getScaledInstance(25,25, Image.SCALE_SMOOTH)));
        reactions[3]=new JToggleButton("Triste",new ImageIcon(new ImageIcon("Images/reactions/TRISTE.png").getImage().getScaledInstance(25,25, Image.SCALE_SMOOTH)));
        reactions[4]=new JToggleButton("Encolere",new ImageIcon(new ImageIcon("Images/reactions/ENCOLERE.png").getImage().getScaledInstance(25,25, Image.SCALE_SMOOTH)));
        for (JToggleButton button:reactions){
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent event) {
                    for (JToggleButton b1:reactions)
                        b1.setSelected(false);
                    button.setSelected(true);
                    //Envoi la reaction a le serveur
                    Socket socket=null;
                    ObjectOutputStream out=null;
                    ObjectInputStream in=null;
                    try {
                        socket=new Socket("127.0.0.1",99);
                        out=new ObjectOutputStream(socket.getOutputStream());
                        in=new ObjectInputStream(socket.getInputStream());
                        out.writeObject(CommandesClientServeur.REAGIR);
                        out.flush();
                        out.write(NumPub);
                        out.flush();

                        out.writeObject(username);
                        out.flush();

                        out.writeObject(visiteur);
                        out.flush();

                        out.writeObject(Reaction.valueOf(button.getText().toUpperCase()));
                        out.flush();
                        in.read();

                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null,"  Desole,erreur de connexion :"+e.getMessage(),"Erreur de Connexion",JOptionPane.ERROR_MESSAGE);
                    }
                    finally {
                        try {
                            socket.close();
                            out.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }
            });
            add(button);
        }

        setBackground(new Color(230,230,230));
    }
}
