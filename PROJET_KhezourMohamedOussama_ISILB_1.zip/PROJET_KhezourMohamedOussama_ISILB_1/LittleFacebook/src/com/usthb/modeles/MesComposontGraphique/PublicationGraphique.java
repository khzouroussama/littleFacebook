package com.usthb.modeles.MesComposontGraphique;

import com.usthb.modeles.ClientFacebook;
import com.usthb.modeles.CommandesClientServeur;
import com.usthb.modeles.Commentaire;
import com.usthb.modeles.MesComposontGraphique.RectionBar;
import com.usthb.modeles.Publication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class PublicationGraphique extends JPanel {

    public PublicationGraphique(Publication publication, String username, String visiteur) {
        super();
        setLayout(new BorderLayout());
        JPanel Contenu=new JPanel(new BorderLayout());

        //le titre de publication
        JLabel titr=new JLabel(username,new ImageIcon(new ImageIcon("Images/user.png").getImage().getScaledInstance(40,40,Image.SCALE_SMOOTH)),SwingConstants.LEFT);
        titr.setBorder(BorderFactory.createTitledBorder(""));
        titr.setFont(ClientFacebook.fontdeFENs);
        titr.setForeground(new Color(70,125,200));
        //le contenu de publication

        JTextArea Contenupub=new JTextArea(publication.getContenu());
        Contenupub.setFont(ClientFacebook.fontdeFENs.deriveFont(Font.PLAIN,14));
        Contenupub.setEditable(false);



        Contenu.add(titr,BorderLayout.NORTH);
        Contenu.add(Contenupub,BorderLayout.CENTER);

        RectionBar reactionBar=new RectionBar(publication.getNum(),username,visiteur);
        if (publication.getReactions().containsKey(visiteur))
            reactionBar.reactions[publication.getReactions().get(visiteur).ordinal()].setSelected(true);

        Contenu.add(reactionBar,BorderLayout.PAGE_END);


        JPanel Coms=new JPanel(new BorderLayout());

        JPanel list=new JPanel();
        list.setBackground(new Color(240,240,230));
        list.setLayout(new BoxLayout(list,BoxLayout.Y_AXIS));

        Coms.add(list,BorderLayout.CENTER);
        list.setBorder(BorderFactory.createLineBorder(Color.lightGray,1,true));
        //ajouter un vide
        Coms.add(new JLabel("     "),BorderLayout.WEST);
        Coms.add(new JLabel("     "),BorderLayout.EAST);

        JLabel noCom=new JLabel("Ajouter le premier Commentaire");
        noCom.setForeground(Color.gray);

        if (publication.getCommentaires().isEmpty())
            list.add(noCom);
        else
            for(Commentaire com:publication.getCommentaires()) {

                JLabel label=new JLabel(new String(com.getContenu()),new ImageIcon(new ImageIcon("Images/user2.png").getImage().getScaledInstance(30,30,Image.SCALE_DEFAULT)),SwingConstants.LEFT);
                label.setBorder(BorderFactory.createTitledBorder(com.getUsername()));
                list.add(label);
                list.revalidate();
            }

        JPanel ajoutCOM=new JPanel(new BorderLayout(5,5));
        JTextField comContenu=new JTextField("");
        JButton commonter=new JButton("Commenter!");
        commonter.setForeground(new Color(100,150,200));
        commonter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                if (comContenu.getText().isEmpty()){
                    JOptionPane.showMessageDialog(getParent(),"Ajouter un commentaire","Commentaire vide",JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    Socket socket=null;
                    ObjectOutputStream out=null;
                    ObjectInputStream in=null;
                    try {
                        socket=new Socket("127.0.0.1",99);
                        out=new ObjectOutputStream(socket.getOutputStream());
                        in=new ObjectInputStream(socket.getInputStream());
                        out.writeObject(CommandesClientServeur.RAJOUTER_COMMENTAIRE);
                        out.flush();
                        out.write(publication.getNum());
                        out.flush();
                        out.writeObject(username);
                        out.flush();
                        out.writeObject(visiteur);   //envoyer le nome de commenteur
                        out.flush();
                        out.writeObject(comContenu.getText());
                        out.flush();

                        noCom.setVisible(false);
                        JLabel l=new JLabel(comContenu.getText(),new ImageIcon(new ImageIcon("Images/user2.png").getImage().getScaledInstance(30,30,Image.SCALE_DEFAULT)),SwingConstants.LEFT);
                        l.setBorder(BorderFactory.createTitledBorder(visiteur));
                        list.add(l);
                        comContenu.setText("");
                        in.read();


                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null,"  Desole,erreur de connexion :"+e.getMessage(),"Erreur de Connexion",JOptionPane.ERROR_MESSAGE);
                    }
                    finally {
                        try {
                            socket.close();
                            out.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
            }
            }
        });

        ajoutCOM.add(comContenu,BorderLayout.CENTER);
        ajoutCOM.add(commonter,BorderLayout.EAST);

        Coms.add(ajoutCOM,BorderLayout.SOUTH);

        setBorder(BorderFactory.createTitledBorder(""));
        Contenu.setBorder(BorderFactory.createLineBorder(Color.lightGray,3));


        add(Contenu,BorderLayout.CENTER);
        add(Coms,BorderLayout.SOUTH);
    }
}
