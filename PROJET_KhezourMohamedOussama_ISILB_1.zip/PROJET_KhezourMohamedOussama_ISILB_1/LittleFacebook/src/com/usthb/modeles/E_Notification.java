package com.usthb.modeles;

public enum E_Notification {
    LUE, NON_LUE
}
